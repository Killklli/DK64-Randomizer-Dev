'Location/item type enum.'
_C='tooltip'
_B='value'
_A='name'
from enum import IntEnum,auto
class Types(IntEnum):'Location/item type enum.';Banana=auto();BlueprintBanana=auto();Shop=auto();Blueprint=auto();Fairy=auto();Key=auto();Crown=auto();Coin=auto();TrainingBarrel=auto();Kong=auto();Medal=auto();Shockwave=auto();Constant=auto();NoItem=auto()
ItemRandoSelector=[{_A:'Shops',_B:'shop',_C:''},{_A:'Golden Bananas',_B:'banana',_C:''},{_A:'Battle Crowns',_B:'crown',_C:''},{_A:'Blueprints',_B:'blueprint',_C:''},{_A:'Keys',_B:'key',_C:''},{_A:'Banana Medals',_B:'medal',_C:''},{_A:'Nintendo/Rareware Coins',_B:'coin',_C:''}]
KeySelector=[{_A:'Key 1',_B:'key1',_C:''},{_A:'Key 2',_B:'key2',_C:''},{_A:'Key 3',_B:'key3',_C:''},{_A:'Key 4',_B:'key4',_C:''},{_A:'Key 5',_B:'key5',_C:''},{_A:'Key 6',_B:'key6',_C:''},{_A:'Key 7',_B:'key7',_C:''},{_A:'Key 8',_B:'key8',_C:''}]