'Import functions within the UI folder to have them run on load of the UI.'
_A=None
from ui.generate_buttons import update_seed_text
from ui.rando_options import set_preset_options,toggle_b_locker_boxes,toggle_counts_boxes,update_boss_required,disable_colors,disable_music,disable_prices,max_randomized_blocker,max_randomized_troff,disable_barrel_rando,disable_boss_rando,hide_rgb,toggle_medals_box,max_randomized_medals,disable_rw
update_seed_text(_A)
set_preset_options()
toggle_counts_boxes(_A)
toggle_b_locker_boxes(_A)
update_boss_required(_A)
disable_colors(_A)
disable_music(_A)
disable_prices(_A)
max_randomized_blocker(_A)
max_randomized_troff(_A)
disable_barrel_rando(_A)
disable_boss_rando(_A)
hide_rgb(_A)
toggle_medals_box(_A)
max_randomized_medals(_A)
disable_rw(_A)