"""Holds the locations and data points for Collectibles."""
