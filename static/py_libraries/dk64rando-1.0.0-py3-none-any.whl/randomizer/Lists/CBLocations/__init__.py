"""List Data for CB Locations."""
