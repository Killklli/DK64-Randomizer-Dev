"""List data for randomizer."""
